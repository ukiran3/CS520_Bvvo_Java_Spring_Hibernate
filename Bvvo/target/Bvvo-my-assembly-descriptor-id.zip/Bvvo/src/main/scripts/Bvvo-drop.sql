﻿drop table users;
drop sequence hibernate_sequence;
drop table reviews;
